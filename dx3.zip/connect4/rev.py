import json
import os
import html
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# --- Configuration ---
# Add the Telegram User IDs of the people allowed to use /reversiclose here:
AUTHORIZED_CLOSERS = [8626582205, 123456789] 

# --- Persistent Data Storage Setup ---
POINTS_FILE = "reversipoints.json"

def load_points():
    """Loads points and upgrades formats automatically."""
    if os.path.exists(POINTS_FILE):
        with open(POINTS_FILE, "r") as file:
            try:
                data = json.load(file)
                for k, v in data.items():
                    if isinstance(v, int):
                        data[k] = {"points": v, "name": f"User_{k}"}
                return data
            except json.JSONDecodeError:
                return {}
    return {}

def save_points(points_data):
    """Saves the current points dictionary to the JSON file."""
    with open(POINTS_FILE, "w") as file:
        json.dump(points_data, file, indent=4)

# --- In-Memory Variables ---
active_games = {}
user_points = load_points()

# Game Constants
BOARD_SIZE = 6 
EMPTY = '➖'   
P1_PIECE = '⚫' 
P2_PIECE = '⚪'

def get_player_info(user):
    """Returns the player's Full Name, safely escaped."""
    return html.escape(user.full_name)

def init_board():
    """Initializes the standard Reversi center pieces."""
    board = [EMPTY] * (BOARD_SIZE * BOARD_SIZE)
    board[2 * BOARD_SIZE + 2] = P2_PIECE
    board[2 * BOARD_SIZE + 3] = P1_PIECE
    board[3 * BOARD_SIZE + 2] = P1_PIECE
    board[3 * BOARD_SIZE + 3] = P2_PIECE
    return board

def get_flips(board, r, c, piece):
    """Returns a list of indices that would be flipped if 'piece' is placed at (r, c)."""
    opponent = P2_PIECE if piece == P1_PIECE else P1_PIECE
    flips = []
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    for dr, dc in directions:
        nr, nc = r + dr, c + dc
        temp_flips = []
        while 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE and board[nr * BOARD_SIZE + nc] == opponent:
            temp_flips.append(nr * BOARD_SIZE + nc)
            nr += dr
            nc += dc
        if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE and board[nr * BOARD_SIZE + nc] == piece and len(temp_flips) > 0:
            flips.extend(temp_flips)
            
    return flips

def get_valid_moves(board, piece):
    """Returns a list of all valid board indices for the current player."""
    moves = []
    for i in range(BOARD_SIZE * BOARD_SIZE):
        if board[i] == EMPTY:
            r, c = i // BOARD_SIZE, i % BOARD_SIZE
            if len(get_flips(board, r, c, piece)) > 0:
                moves.append(i)
    return moves

def count_pieces(board):
    """Counts current Black and White pieces."""
    b = board.count(P1_PIECE)
    w = board.count(P2_PIECE)
    return b, w

def get_board_markup(board):
    """Generates the clean 6x6 inline keyboard."""
    keyboard = []
    for r in range(BOARD_SIZE):
        row = []
        for c in range(BOARD_SIZE):
            idx = r * BOARD_SIZE + c
            btn_text = board[idx]
            row.append(InlineKeyboardButton(btn_text, callback_data=f"rev_{idx}"))
        keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

def safe_remove_job(job):
    if job:
        try:
            job.schedule_removal()
        except Exception:
            pass

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /reversirules command."""
    rules_text = (
        "🎮 <b>How to Play Othello (Reversi)</b> 🎮\n\n"
        "<b>The Goal:</b> Finish the game with more pieces of your color on the board than your opponent!\n\n"
        "<b>How to move:</b>\n"
        "1️⃣ Type /reversi to start a game. Player 1 is ⚫.\n"
        "2️⃣ You MUST place your piece so that you 'trap' opponent pieces between your new piece and another piece of your color.\n"
        "3️⃣ All trapped opponent pieces flip to your color!\n\n"
        "<i>Note: If you have no valid moves, your turn is automatically skipped!</i>\n\n"
        "<b>Commands:</b>\n"
        "• /reversi - Start a new game\n"
        "• /reversiclose - Force stop a stuck game\n"
        "• /reversipoints - Check the Top 20 leaderboard"
    )
    await update.message.reply_text(rules_text, parse_mode="HTML")

async def live_countdown(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    chat_id = job.data['chat_id']

    if chat_id not in active_games:
        safe_remove_job(job)
        return

    game = active_games[chat_id]
    
    if game.get('is_processing'):
        return

    game['time_left'] -= 3

    if game['time_left'] <= 0:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text="⏳ <b>Game Closed!</b>\n\nAutomatically closed due to 60 seconds of inactivity.\n\nType /reversi to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
        
        del active_games[chat_id]
        safe_remove_job(job)
    else:
        try:
            text = f"{game['base_text']}\n\n(⏳ {game['time_left']} seconds remaining)"
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text,
                reply_markup=get_board_markup(game['board']),
                parse_mode="HTML"
            )
        except Exception:
            pass 

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        await update.message.reply_text("❌ A Reversi game is already running! Finish it or ask an admin to type /reversiclose.")
        return

    player_info = get_player_info(user)
    board = init_board()
    valid_moves = get_valid_moves(board, P1_PIECE)
    
    base_text = (
        f"🎮 <b>Othello (Reversi) started!</b>\n\n"
        f"⚫ Player 1: {player_info} (Score: 2)\n"
        f"⚪ Player 2: Waiting for opponent... (Score: 2)\n\n"
        f"It is ⚫'s turn!\n\n"
        f"📖 <i>Type /reversirules for rules</i>"
    )

    active_games[chat_id] = {
        'board': board,
        'player_1': user,
        'player_1_info': player_info,
        'player_2': None,
        'player_2_info': "Waiting for opponent...",
        'turn': P1_PIECE,
        'valid_moves': valid_moves,
        'message_id': None,
        'timer_job': None,
        'time_left': 60,
        'base_text': base_text,
        'is_processing': False
    }

    markup = get_board_markup(board)
    message = await update.message.reply_text(
        f"{base_text}\n\n(⏳ 60 seconds remaining)",
        reply_markup=markup,
        parse_mode="HTML"
    )
    
    active_games[chat_id]['message_id'] = message.message_id

    job = context.job_queue.run_repeating(
        live_countdown, interval=3, first=3, data={'chat_id': chat_id}
    )
    active_games[chat_id]['timer_job'] = job

async def close_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user

    # --- Permission Check ---
    if user.id not in AUTHORIZED_CLOSERS:
        await update.message.reply_text("❌ You do not have permission to force close games.", parse_mode="HTML")
        return

    if chat_id in active_games:
        game = active_games[chat_id]
        safe_remove_job(game.get('timer_job'))
        closer_name = get_player_info(user)
            
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=f"🛑 <b>Game Forcefully Closed!</b>\n\nGame has closed by {closer_name}.\n\nType /reversi to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
            
        del active_games[chat_id]
        await update.message.reply_text(f"✅ Game has closed by <b>{closer_name}</b>.", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ There is no active Reversi game running right now.", parse_mode="HTML")

async def handle_move(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    user = update.effective_user
    data = query.data

    if not data.startswith("rev_"):
        return

    if chat_id not in active_games:
        await query.answer("This game has already ended!", show_alert=True)
        return

    game = active_games[chat_id]

    if game.get('is_processing'):
        await query.answer("⏳ Wait a moment...", show_alert=False)
        return

    if query.message.message_id != game['message_id']:
        await query.answer("This is an old game board!", show_alert=True)
        return

    idx = int(data.split('_')[1])
    board = game['board']

    if game['turn'] == P1_PIECE:
        if user.id != game['player_1'].id:
            await query.answer("It's not your turn, or you are not Player ⚫!", show_alert=True)
            return
    else:
        if game['player_2'] is None:
            if user.id == game['player_1'].id:
                await query.answer("You can't play against yourself! Let someone else join.", show_alert=True)
                return
            game['player_2'] = user
            game['player_2_info'] = get_player_info(user)
        elif user.id != game['player_2'].id:
            await query.answer("It's not your turn, or you are not Player ⚪!", show_alert=True)
            return

    if idx not in game['valid_moves']:
        await query.answer("Invalid move! You must place your piece so that it traps at least one opponent piece.", show_alert=True)
        return

    await query.answer()
    game['is_processing'] = True

    try:
        safe_remove_job(game.get('timer_job'))

        r, c = idx // BOARD_SIZE, idx % BOARD_SIZE
        flips = get_flips(board, r, c, game['turn'])
        
        board[idx] = game['turn']
        for f in flips:
            board[f] = game['turn']

        next_turn = P2_PIECE if game['turn'] == P1_PIECE else P1_PIECE
        next_moves = get_valid_moves(board, next_turn)
        skipped_text = ""

        if not next_moves:
            current_moves = get_valid_moves(board, game['turn'])
            if not current_moves:
                # Game Over Logic
                b_score, w_score = count_pieces(board)
                
                if b_score > w_score:
                    winning_user = game['player_1']
                    winning_info = game['player_1_info']
                    text = f"🏆 <b>Game Over!</b>\n\n⚫ Black: {b_score} | ⚪ White: {w_score}\nWinner: {winning_info} earns <b>20 points</b>! 🎉"
                elif w_score > b_score:
                    winning_user = game['player_2']
                    winning_info = game['player_2_info']
                    text = f"🏆 <b>Game Over!</b>\n\n⚫ Black: {b_score} | ⚪ White: {w_score}\nWinner: {winning_info} earns <b>20 points</b>! 🎉"
                else:
                    winning_user = None
                    text = f"🤝 <b>Game Over!</b>\n\n⚫ Black: {b_score} | ⚪ White: {w_score}\nIt's a Tie! Nobody gets points."

                if winning_user:
                    user_id_str = str(winning_user.id)
                    if user_id_str not in user_points:
                        user_points[user_id_str] = {"points": 0, "name": winning_info}
                    user_points[user_id_str]["points"] += 20 
                    user_points[user_id_str]["name"] = winning_info 
                    save_points(user_points)

                text += "\n\nType /reversi to play again."
                
                # Retry loop to ensure Game Over screen delivers
                for _ in range(3):
                    try:
                        await context.bot.edit_message_text(
                            chat_id=chat_id, message_id=game['message_id'],
                            text=text, reply_markup=get_board_markup(board), parse_mode="HTML"
                        )
                        break
                    except Exception:
                        await asyncio.sleep(0.5)
                        
                del active_games[chat_id]
                return
            else:
                skipped_text = f"\n\n⚠️ <b>{next_turn}</b> has no valid moves and was skipped!"
                game['valid_moves'] = current_moves
        else:
            game['turn'] = next_turn
            game['valid_moves'] = next_moves

        b_score, w_score = count_pieces(board)
        
        game['base_text'] = (
            f"🎮 <b>Othello (Reversi)</b>\n\n"
            f"⚫ Player 1: {game['player_1_info']} (Score: {b_score})\n"
            f"⚪ Player 2: {game['player_2_info']} (Score: {w_score})\n\n"
            f"It is <b>{game['turn']}</b>'s turn!{skipped_text}"
        )
        game['time_left'] = 60
        
        # 1. SETUP THE TIMER FIRST - Guaranteeing an auto-heal if the UI edit fails
        new_job = context.job_queue.run_repeating(
            live_countdown, interval=3, first=3, data={'chat_id': chat_id}
        )
        game['timer_job'] = new_job

        # 2. ATTEMPT UI UPDATE SAFELY
        text = f"{game['base_text']}\n\n(⏳ 60 seconds remaining)"
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(board), 
                parse_mode="HTML"
            )
        except Exception:
            pass

    except Exception as e:
        print(f"Error processing move: {e}")
        
    finally:
        if chat_id in active_games:
            active_games[chat_id]['is_processing'] = False

async def check_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the Top 20 players for Reversi."""
    user = update.effective_user
    user_id_str = str(user.id)
    
    user_data = user_points.get(user_id_str, {"points": 0})
    personal_points = user_data["points"]

    sorted_players = sorted(user_points.items(), key=lambda x: x[1]['points'], reverse=True)
    top_20 = sorted_players[:20]

    if not top_20:
        await update.message.reply_text("📋 <b>Leaderboard is empty!</b> Play some games first.", parse_mode="HTML")
        return

    text = "🏆 <b>TOP 20 REVERSI PLAYERS</b> 🏆\n━━━━━━━━━━━━━━━━━━━━\n"
    
    for rank, (uid, data) in enumerate(top_20, 1):
        if rank == 1: medal = "🥇"
        elif rank == 2: medal = "🥈"
        elif rank == 3: medal = "🥉"
        else: medal = "🏅"
        text += f"{medal} <b>{data['name']}</b>: {data['points']} pts\n"
        
    text += "━━━━━━━━━━━━━━━━━━━━\n"
    text += f"👤 <b>Your Total Points:</b> {personal_points}"

    await update.message.reply_text(text, parse_mode="HTML")

if __name__ == '__main__':
    app = Application.builder().token("8730956259:AAFuW-Iqrnmz58ks1IEya-4Ud2Y3im84LTk").build()

    app.add_handler(CommandHandler("reversi", start_game))
    app.add_handler(CommandHandler("reversiclose", close_game)) 
    app.add_handler(CommandHandler("reversipoints", check_points))
    app.add_handler(CommandHandler("reversirules", show_rules))
    app.add_handler(CallbackQueryHandler(handle_move, pattern="^rev_"))

    print("Reversi/Othello Bot is running with authorized closures...")
    app.run_polling()
