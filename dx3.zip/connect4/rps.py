import json
import os
import html
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# --- Persistent Data Storage Setup ---
POINTS_FILE = "rpspoints.json"

def load_points():
    """Loads points and upgrades formats automatically."""
    if os.path.exists(POINTS_FILE):
        with open(POINTS_FILE, "r") as file:
            try:
                data = json.load(file)
                for k, v in data.items():
                    if isinstance(v, int):
                        data[k] = {"points": v, "name": f"User_{k}"}
                return data
            except json.JSONDecodeError:
                return {}
    return {}

def save_points(points_data):
    """Saves the current points dictionary to the JSON file."""
    with open(POINTS_FILE, "w") as file:
        json.dump(points_data, file, indent=4)

# --- In-Memory Variables ---
active_games = {}
user_points = load_points()

# RPS Logic Mapping
EMOJIS = {'r': '🪨 Rock', 'p': '📜 Paper', 's': '✂️ Scissors'}
WINS_AGAINST = {'r': 's', 'p': 'r', 's': 'p'}

def get_player_info(user):
    """Returns the player's Full Name, safely escaped."""
    return html.escape(user.full_name)

def get_board_markup():
    """Generates the 3 buttons for Rock, Paper, Scissors."""
    keyboard = [
        [
            InlineKeyboardButton("🪨 Rock", callback_data="rps_r"),
            InlineKeyboardButton("📜 Paper", callback_data="rps_p"),
            InlineKeyboardButton("✂️ Scissors", callback_data="rps_s")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def determine_winner(p1_choice, p2_choice):
    """Returns 1 if Player 1 wins, 2 if Player 2 wins, and 0 for a draw."""
    if p1_choice == p2_choice:
        return 0
    if WINS_AGAINST[p1_choice] == p2_choice:
        return 1
    return 2

def safe_remove_job(job):
    """Safely removes a scheduled job, ignoring errors if it was already removed."""
    if job:
        try:
            job.schedule_removal()
        except Exception:
            pass

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /rpsrules command to explain the game."""
    rules_text = (
        "🎮 <b>How to Play Rock-Paper-Scissors</b> 🎮\n\n"
        "<b>The Goal:</b> Pick the winning hand to beat your opponent!\n"
        "🪨 Rock beats ✂️ Scissors\n"
        "✂️ Scissors beats 📜 Paper\n"
        "📜 Paper beats 🪨 Rock\n\n"
        "<b>How to move:</b>\n"
        "1️⃣ Type /rps to start a game.\n"
        "2️⃣ Tap your choice! The bot will secretly lock it in.\n"
        "3️⃣ A second player taps their choice to join.\n"
        "4️⃣ Once both players are locked in, the hands are revealed!\n\n"
        "<b>Commands:</b>\n"
        "• /rps - Start a new game\n"
        "• /rpsclose - Force stop a stuck game\n"
        "• /rpspoints - Check the Top 20 leaderboard\n"
        "• /rpsrules - Show this message"
    )
    await update.message.reply_text(rules_text, parse_mode="HTML")

async def live_countdown(context: ContextTypes.DEFAULT_TYPE):
    """Updates the message every 3 seconds to show a live countdown."""
    job = context.job
    chat_id = job.data['chat_id']

    if chat_id not in active_games:
        safe_remove_job(job)
        return

    game = active_games[chat_id]
    
    if game.get('is_processing'):
        return

    game['time_left'] -= 3

    if game['time_left'] <= 0:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text="⏳ <b>Game Closed!</b>\n\nAutomatically closed due to 60 seconds of inactivity.\n\nType /rps to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
        
        del active_games[chat_id]
        safe_remove_job(job)
    else:
        try:
            # Build current status text
            p1_status = "✅ Locked in!" if game['p1_choice'] else "🤔 Thinking..."
            p2_status = "✅ Locked in!" if game['p2_choice'] else "🤔 Thinking..."
            
            text = (
                f"🎮 <b>Rock Paper Scissors!</b>\n\n"
                f"👤 Player 1: {game['player_1_info']} ({p1_status})\n"
                f"👤 Player 2: {game['player_2_info']} ({p2_status})\n\n"
                f"(⏳ {game['time_left']} seconds remaining)\n\n"
                f"📖 <i>Type /rpsrules for rules</i>"
            )
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text,
                reply_markup=get_board_markup(),
                parse_mode="HTML"
            )
        except Exception:
            pass 

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /rps command to start a game."""
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        await update.message.reply_text("❌ An RPS game is already running in this group! Finish it or type /rpsclose to force close it.")
        return

    player_info = get_player_info(user)
    
    text = (
        f"🎮 <b>Rock Paper Scissors!</b>\n\n"
        f"👤 Player 1: {player_info} (🤔 Thinking...)\n"
        f"👤 Player 2: Waiting for opponent... (🤔 Thinking...)\n\n"
        f"(⏳ 60 seconds remaining)\n\n"
        f"📖 <i>Type /rpsrules for rules</i>"
    )

    active_games[chat_id] = {
        'player_1': user,
        'player_1_info': player_info,
        'p1_choice': None,
        
        'player_2': None,
        'player_2_info': "Waiting for opponent...",
        'p2_choice': None,
        
        'message_id': None,
        'timer_job': None,
        'time_left': 60,
        'is_processing': False
    }

    markup = get_board_markup()
    message = await update.message.reply_text(text=text, reply_markup=markup, parse_mode="HTML")
    
    active_games[chat_id]['message_id'] = message.message_id

    job = context.job_queue.run_repeating(
        live_countdown, 
        interval=3, 
        first=3,
        data={'chat_id': chat_id}
    )
    active_games[chat_id]['timer_job'] = job

async def close_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /rpsclose command."""
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        game = active_games[chat_id]
        safe_remove_job(game.get('timer_job'))
        closer_name = get_player_info(user)
            
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=f"🛑 <b>Game Forcefully Closed!</b>\n\nGame has closed by {closer_name}.\n\nType /rps to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
            
        del active_games[chat_id]
        await update.message.reply_text(f"✅ Game has closed by <b>{closer_name}</b>.", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ There is no active RPS game running right now.", parse_mode="HTML")

async def handle_move(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles button clicks for Rock, Paper, Scissors."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    user = update.effective_user
    data = query.data

    if not data.startswith("rps_"):
        return

    if chat_id not in active_games:
        await query.answer("This game has already ended or timed out!", show_alert=True)
        return

    game = active_games[chat_id]

    if game.get('is_processing'):
        await query.answer("⏳ Processing, please wait...", show_alert=False)
        return

    if query.message.message_id != game['message_id']:
        await query.answer("This is an old game board!", show_alert=True)
        return

    # Extract 'r', 'p', or 's'
    choice = data.split('_')[1]

    # Player 1 Registration
    if user.id == game['player_1'].id:
        if game['p1_choice'] is not None:
            await query.answer("You already locked in your choice!", show_alert=False)
            return
        game['p1_choice'] = choice

    # Player 2 Registration
    else:
        if game['player_2'] is None:
            # New player joins
            game['player_2'] = user
            game['player_2_info'] = get_player_info(user)
            game['p2_choice'] = choice
        elif user.id == game['player_2'].id:
            # P2 clicks again
            if game['p2_choice'] is not None:
                await query.answer("You already locked in your choice!", show_alert=False)
                return
            game['p2_choice'] = choice
        else:
            # A 3rd person tries to click
            await query.answer("This game is full! Player 1 and Player 2 are already playing.", show_alert=True)
            return

    # Acknowledge the tap IMMEDIATELY to prevent Telegram timeouts/lag spinners!
    await query.answer(f"Secretly locked in {EMOJIS[choice]}!", show_alert=False)
    
    # Now lock the board to process safely
    game['is_processing'] = True

    try:
        # Check if BOTH players have chosen
        if game['p1_choice'] and game['p2_choice']:
            safe_remove_job(game.get('timer_job'))
            
            p1_c = game['p1_choice']
            p2_c = game['p2_choice']
            
            result = determine_winner(p1_c, p2_c)
            
            text = (
                f"💥 <b>THE REVEAL!</b> 💥\n\n"
                f"👤 {game['player_1_info']}: {EMOJIS[p1_c]}\n"
                f"👤 {game['player_2_info']}: {EMOJIS[p2_c]}\n\n"
            )
            
            # Award points and finalize text
            if result == 1:
                winner_info = game['player_1_info']
                winner_id = str(game['player_1'].id)
                text += f"🏆 <b>{winner_info} wins and earns 10 points!</b> 🎉"
                
                if winner_id not in user_points:
                    user_points[winner_id] = {"points": 0, "name": winner_info}
                user_points[winner_id]["points"] += 10
                user_points[winner_id]["name"] = winner_info
                save_points(user_points)
                
            elif result == 2:
                winner_info = game['player_2_info']
                winner_id = str(game['player_2'].id)
                text += f"🏆 <b>{winner_info} wins and earns 10 points!</b> 🎉"
                
                if winner_id not in user_points:
                    user_points[winner_id] = {"points": 0, "name": winner_info}
                user_points[winner_id]["points"] += 10
                user_points[winner_id]["name"] = winner_info
                save_points(user_points)
                
            else:
                text += "🤝 <b>It's a Draw! Nobody gets points.</b>"
            
            text += "\n\nType /rps to play again."
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                parse_mode="HTML" # Removing the reply_markup removes the buttons
            )
            del active_games[chat_id]
            
        else:
            # Both players haven't chosen yet. Update the display to show who locked in!
            p1_status = "✅ Locked in!" if game['p1_choice'] else "🤔 Thinking..."
            p2_status = "✅ Locked in!" if game['p2_choice'] else "🤔 Thinking..."
            
            # Reset timer back to 60 for the other player
            game['time_left'] = 60
            
            text = (
                f"🎮 <b>Rock Paper Scissors!</b>\n\n"
                f"👤 Player 1: {game['player_1_info']} ({p1_status})\n"
                f"👤 Player 2: {game['player_2_info']} ({p2_status})\n\n"
                f"(⏳ 60 seconds remaining)\n\n"
                f"📖 <i>Type /rpsrules for rules</i>"
            )
            
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(), 
                parse_mode="HTML"
            )
            
            # Restart live countdown
            safe_remove_job(game.get('timer_job'))
            new_job = context.job_queue.run_repeating(
                live_countdown, 
                interval=3, 
                first=3,
                data={'chat_id': chat_id}
            )
            game['timer_job'] = new_job

    except Exception as e:
        pass # Handle Telegram visual lag silently 
        
    finally:
        if chat_id in active_games:
            active_games[chat_id]['is_processing'] = False

async def check_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the Top 20 players for RPS."""
    user = update.effective_user
    user_id_str = str(user.id)
    
    user_data = user_points.get(user_id_str, {"points": 0})
    personal_points = user_data["points"]

    sorted_players = sorted(user_points.items(), key=lambda x: x[1]['points'], reverse=True)
    top_20 = sorted_players[:20]

    if not top_20:
        await update.message.reply_text("📋 <b>Leaderboard is empty!</b> Play some games first.", parse_mode="HTML")
        return

    text = "🏆 <b>TOP 20 RPS PLAYERS</b> 🏆\n━━━━━━━━━━━━━━━━━━━━\n"
    
    for rank, (uid, data) in enumerate(top_20, 1):
        if rank == 1:
            medal = "🥇"
        elif rank == 2:
            medal = "🥈"
        elif rank == 3:
            medal = "🥉"
        else:
            medal = "🏅"
            
        text += f"{medal} <b>{data['name']}</b>: {data['points']} pts\n"
        
    text += "━━━━━━━━━━━━━━━━━━━━\n"
    text += f"👤 <b>Your Total Points:</b> {personal_points}"

    await update.message.reply_text(text, parse_mode="HTML")

if __name__ == '__main__':
    app = Application.builder().token("8730956259:AAFuW-Iqrnmz58ks1IEya-4Ud2Y3im84LTk").build()

    app.add_handler(CommandHandler("rps", start_game))
    app.add_handler(CommandHandler("rpsclose", close_game)) 
    app.add_handler(CommandHandler("rpspoints", check_points))
    app.add_handler(CommandHandler("rpsrules", show_rules))
    app.add_handler(CallbackQueryHandler(handle_move, pattern="^rps_"))

    print("Blind Rock-Paper-Scissors Bot is running lag-free...")
    app.run_polling()
