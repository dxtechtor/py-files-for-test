import os
import random

from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
)

TOKEN = "8980626883:AAG6jhMhmKtNQm5EWTma8blKTSIoDP5BlwA"

# Stores one game per chat
games = {}


def board_image(board, filename):
    svg = chess.svg.board(board=board)
    cairosvg.svg2png(bytestring=svg.encode("utf-8"), write_to=filename)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    board = chess.Board()
    games[update.effective_chat.id] = board

    img = "board.png"
    board_image(board, img)

    await update.message.reply_text(
        "♟ New Chess Game Started!\n"
        "You are White.\n"
        "Use:\n"
        "/move e2e4"
    )

    await update.message.reply_photo(photo=open(img, "rb"))


async def board(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.id not in games:
        games[update.effective_chat.id] = chess.Board()

    b = games[update.effective_chat.id]

    img = "board.png"
    board_image(b, img)

    await update.message.reply_photo(photo=open(img, "rb"))

async def move(update, context):
    chat_id = update.effective_chat.id

    if chat_id not in games:
        return

    game = games[chat_id]
    board = game["board"]
    user = update.effective_user.id

    if board.turn == chess.WHITE:
        if user != game["white"]:
            await update.message.reply_text("It's White's turn.")
            return
    else:
        if user != game["black"]:
            await update.message.reply_text("It's Black's turn.")
            return

    if not context.args:
        await update.message.reply_text("Example: /move e2e4")
        return

    try:
        move = chess.Move.from_uci(context.args[0])

        if move not in board.legal_moves:
            await update.message.reply_text("Illegal move.")
            return

        board.push(move)

        if board.is_checkmate():
            winner = (
                game["white_name"]
                if not board.turn
                else game["black_name"]
            )

            await update.message.reply_text(
                f"Checkmate!\n{winner} wins."
            )

            del games[chat_id]
            return

        await update.message.reply_text(
            f"Move played: {context.args[0]}"
        )

    except Exception:
        await update.message.reply_text("Invalid move.")

async def create(update, context):
    chat_id = update.effective_chat.id

    if chat_id in games:
        await update.message.reply_text("A game is already running.")
        return

    games[chat_id] = {
        "board": chess.Board(),
        "white": update.effective_user.id,
        "white_name": update.effective_user.first_name,
        "black": None,
        "black_name": None,
        "status": "waiting"
    }

    await update.message.reply_text(
        f"{update.effective_user.first_name} created a chess game.\n"
        "Another player can join with /join"
    )
    
async def join(update, context):
    chat_id = update.effective_chat.id

    if chat_id not in games:
        await update.message.reply_text("No game available.")
        return

    game = games[chat_id]

    if game["black"] is not None:
        await update.message.reply_text("Game already has two players.")
        return

    if update.effective_user.id == game["white"]:
        await update.message.reply_text("You can't join your own game.")
        return

    game["black"] = update.effective_user.id
    game["black_name"] = update.effective_user.first_name
    game["status"] = "playing"

    await update.message.reply_text(
        f"{game['white_name']} (White) vs "
        f"{game['black_name']} (Black)\n"
        "White to move."
    )
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start - New Game\n"
        "/board - Show Board\n"
        "/move e2e4 - Make Move"
    )


def main():
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("board", board))
    app.add_handler(CommandHandler("move", move))
    app.add_handler(CommandHandler("help", help_command))

    print("Bot Running...")
    app.run_polling()


if name == "main":
    main()