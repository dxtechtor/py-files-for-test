import json
import os
import html
import asyncio
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# --- Configuration ---
# Add the Telegram User IDs of the people allowed to use /msclose here:
AUTHORIZED_CLOSERS = [8626582205, 123456789] 

# --- Persistent Data Storage Setup ---
POINTS_FILE = "mspoints.json"

def load_points():
    """Loads points and upgrades formats automatically."""
    if os.path.exists(POINTS_FILE):
        with open(POINTS_FILE, "r") as file:
            try:
                data = json.load(file)
                for k, v in data.items():
                    if isinstance(v, int):
                        data[k] = {"points": v, "name": f"User_{k}"}
                return data
            except json.JSONDecodeError:
                return {}
    return {}

def save_points(points_data):
    """Saves the current points dictionary to the JSON file."""
    with open(POINTS_FILE, "w") as file:
        json.dump(points_data, file, indent=4)

# --- In-Memory Variables ---
active_games = {}
user_points = load_points()

# Game Constants
BOARD_SIZE = 8 # Upgraded to 8x8!
NUM_MINES = 10 # 10 Mines for a classic 8x8 board
TOTAL_SAFE_TILES = (BOARD_SIZE * BOARD_SIZE) - NUM_MINES

HIDDEN = '⬜'
MINE = '💣'
EMPTY_REVEALED = '0️⃣' # Upgraded to show explicit 0s!
NUM_EMOJIS = {1: '1️⃣', 2: '2️⃣', 3: '3️⃣', 4: '4️⃣', 5: '5️⃣', 6: '6️⃣', 7: '7️⃣', 8: '8️⃣'}

P1_ICON = '🔴'
P2_ICON = '🔵'

def get_player_info(user):
    """Returns the player's Full Name, safely escaped."""
    return html.escape(user.full_name)

def init_empty_boards():
    """Creates a completely blank board. Mines are generated on the first click!"""
    hidden = [0] * (BOARD_SIZE * BOARD_SIZE)
    visible = [HIDDEN] * (BOARD_SIZE * BOARD_SIZE)
    return hidden, visible

def generate_board(clicked_idx):
    """Generates mines safely away from the first clicked tile to guarantee a cascade."""
    hidden = [0] * (BOARD_SIZE * BOARD_SIZE)
    
    # Identify the clicked tile and its immediate neighbors to exclude them from mine placement
    exclude = set([clicked_idx])
    r, c = clicked_idx // BOARD_SIZE, clicked_idx % BOARD_SIZE
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    for dr, dc in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE:
            exclude.add(nr * BOARD_SIZE + nc)
            
    # Pool of available tiles for mines
    available = [i for i in range(BOARD_SIZE * BOARD_SIZE) if i not in exclude]
    
    # Fallback just in case the board is tiny, though not an issue for 8x8
    if len(available) < NUM_MINES:
        available = [i for i in range(BOARD_SIZE * BOARD_SIZE) if i != clicked_idx]
        
    mines = random.sample(available, NUM_MINES)
    for m in mines:
        hidden[m] = 'M'
        
    # Calculate adjacency numbers for the rest of the board
    for row in range(BOARD_SIZE):
        for col in range(BOARD_SIZE):
            idx = row * BOARD_SIZE + col
            if hidden[idx] == 'M':
                continue
            count = 0
            for dr, dc in directions:
                nr, nc = row + dr, col + dc
                if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE:
                    if hidden[nr * BOARD_SIZE + nc] == 'M':
                        count += 1
            hidden[idx] = count
            
    return hidden

def reveal_cell(hidden, visible, idx):
    """Reveals the cell and performs a flood-fill if it's a 0. Returns points earned (-1 for mine)."""
    if visible[idx] != HIDDEN:
        return 0

    val = hidden[idx]
    if val == 'M':
        visible[idx] = MINE
        return -1 

    if val > 0:
        visible[idx] = NUM_EMOJIS[val]
        return 1

    # Flood fill logic for completely empty spots (0)
    queue = [idx]
    visible[idx] = EMPTY_REVEALED
    revealed_count = 1
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    while queue:
        curr = queue.pop(0)
        r, c = curr // BOARD_SIZE, curr % BOARD_SIZE

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE:
                n_idx = nr * BOARD_SIZE + nc
                if visible[n_idx] == HIDDEN:
                    n_val = hidden[n_idx]
                    if n_val == 0:
                        visible[n_idx] = EMPTY_REVEALED
                        queue.append(n_idx)
                        revealed_count += 1
                    elif n_val != 'M':
                        visible[n_idx] = NUM_EMOJIS[n_val]
                        revealed_count += 1

    return revealed_count

def get_board_markup(visible_board):
    """Generates the 8x8 inline keyboard."""
    keyboard = []
    for r in range(BOARD_SIZE):
        row = []
        for c in range(BOARD_SIZE):
            idx = r * BOARD_SIZE + c
            row.append(InlineKeyboardButton(visible_board[idx], callback_data=f"ms_{idx}"))
        keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

def apply_global_points(user_id, user_name, points):
    user_id_str = str(user_id)
    if user_id_str not in user_points:
        user_points[user_id_str] = {"points": 0, "name": user_name}
    user_points[user_id_str]["points"] += points
    user_points[user_id_str]["name"] = user_name
    save_points(user_points)

def safe_remove_job(job):
    if job:
        try:
            job.schedule_removal()
        except Exception:
            pass

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /msrules command."""
    rules_text = (
        "🎮 <b>How to Play Multiplayer Minesweeper</b> 🎮\n\n"
        "<b>The Goal:</b> Score the most points by clearing safe tiles!\n\n"
        "<b>Point System & Rules:</b>\n"
        "✅ <b>+1 Point</b> for every safe tile or number you reveal.\n"
        "0️⃣ <b>Safe Zones:</b> Zeroes (0️⃣) mean there are NO mines nearby!\n"
        "💥 <b>SUDDEN DEATH:</b> If you click a Mine (💣), you lose 3 points and the <b>game ends immediately!</b>\n\n"
        "<b>How to move:</b>\n"
        "1️⃣ Type /ms to start a game. Player 1 is 🔴.\n"
        "2️⃣ Player 2 (🔵) joins by tapping any unrevealed tile ⬜.\n\n"
        "<b>Commands:</b>\n"
        "• /ms - Start a new game\n"
        "• /msclose - Force stop a stuck game\n"
        "• /mspoints - Check the Top 20 leaderboard"
    )
    await update.message.reply_text(rules_text, parse_mode="HTML")

async def live_countdown(context: ContextTypes.DEFAULT_TYPE):
    job = context.job
    chat_id = job.data['chat_id']

    if chat_id not in active_games:
        safe_remove_job(job)
        return

    game = active_games[chat_id]
    
    if game.get('is_processing'):
        return

    game['time_left'] -= 3

    if game['time_left'] <= 0:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text="⏳ <b>Game Closed!</b>\n\nAutomatically closed due to 180 seconds of inactivity.\n\nType /ms to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
        
        del active_games[chat_id]
        safe_remove_job(job)
    else:
        try:
            text = f"{game['base_text']}\n\n(⏳ {game['time_left']} seconds remaining)"
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text,
                reply_markup=get_board_markup(game['visible_board']),
                parse_mode="HTML"
            )
        except Exception:
            pass 

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        await update.message.reply_text("❌ A Minesweeper game is already running! Finish it or ask an admin to type /msclose.")
        return

    player_info = get_player_info(user)
    
    # Initialize totally empty boards. Mines will generate on the first click!
    hidden, visible = init_empty_boards()
    
    base_text = (
        f"🎮 <b>Minesweeper Raid Started!</b>\n\n"
        f"🔴 Player 1: {player_info} (Score: 0)\n"
        f"🔵 Player 2: Waiting for opponent... (Score: 0)\n\n"
        f"It is 🔴's turn!\n\n"
        f"📖 <i>Type /msrules for rules</i>"
    )

    active_games[chat_id] = {
        'hidden_board': hidden,
        'visible_board': visible,
        'first_move': True, # Tracks if the board needs to generate mines
        'safe_revealed': 0,
        'player_1': user,
        'player_1_info': player_info,
        'p1_score': 0,
        'player_2': None,
        'player_2_info': "Waiting for opponent...",
        'p2_score': 0,
        'turn': 1,
        'last_action': "",
        'message_id': None,
        'timer_job': None,
        'time_left': 180,
        'is_processing': False
    }

    markup = get_board_markup(visible)
    message = await update.message.reply_text(
        f"{base_text}\n\n(⏳ 180 seconds remaining)",
        reply_markup=markup,
        parse_mode="HTML"
    )
    
    active_games[chat_id]['message_id'] = message.message_id

    job = context.job_queue.run_repeating(
        live_countdown, interval=3, first=3, data={'chat_id': chat_id}
    )
    active_games[chat_id]['timer_job'] = job

async def close_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user

    if user.id not in AUTHORIZED_CLOSERS:
        await update.message.reply_text("❌ You do not have permission to force close games.", parse_mode="HTML")
        return

    if chat_id in active_games:
        game = active_games[chat_id]
        safe_remove_job(game.get('timer_job'))
        closer_name = get_player_info(user)
            
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=f"🛑 <b>Game Forcefully Closed!</b>\n\nGame has closed by {closer_name}.\n\nType /ms to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
            
        del active_games[chat_id]
        await update.message.reply_text(f"✅ Game has closed by <b>{closer_name}</b>.", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ There is no active Minesweeper game running right now.", parse_mode="HTML")

async def handle_move(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    user = update.effective_user
    data = query.data

    if not data.startswith("ms_"):
        return

    if chat_id not in active_games:
        await query.answer("This game has already ended!", show_alert=True)
        return

    game = active_games[chat_id]

    if game.get('is_processing'):
        await query.answer("⏳ Wait a moment...", show_alert=False)
        return

    if query.message.message_id != game['message_id']:
        await query.answer("This is an old game board!", show_alert=True)
        return

    idx = int(data.split('_')[1])
    visible = game['visible_board']
    
    # Generate the board on the very first tap!
    if game.get('first_move'):
        game['hidden_board'] = generate_board(idx)
        game['first_move'] = False
        
    hidden = game['hidden_board']

    if visible[idx] != HIDDEN:
        await query.answer("This tile is already revealed!", show_alert=False)
        return

    # Turn logic
    if game['turn'] == 1:
        if user.id != game['player_1'].id:
            await query.answer("It's not your turn, or you are not Player 🔴!", show_alert=True)
            return
        current_icon = P1_ICON
    else:
        if game['player_2'] is None:
            if user.id == game['player_1'].id:
                await query.answer("You can't play against yourself! Let someone else join.", show_alert=True)
                return
            game['player_2'] = user
            game['player_2_info'] = get_player_info(user)
        elif user.id != game['player_2'].id:
            await query.answer("It's not your turn, or you are not Player 🔵!", show_alert=True)
            return
        current_icon = P2_ICON

    await query.answer()
    game['is_processing'] = True

    try:
        safe_remove_job(game.get('timer_job'))

        # Reveal logic
        points_earned = reveal_cell(hidden, visible, idx)
        
        # ==========================================
        # 💥 GAME OVER LOGIC: MINE EXPLODED
        # ==========================================
        if points_earned == -1:
            points_to_award = -3
            
            # Apply penalties
            if game['turn'] == 1:
                game['p1_score'] += points_to_award
                apply_global_points(game['player_1'].id, game['player_1_info'], points_to_award)
            else:
                game['p2_score'] += points_to_award
                apply_global_points(game['player_2'].id, game['player_2_info'], points_to_award)
                
            # Reveal all remaining mines for the final game over screen
            for i in range(BOARD_SIZE * BOARD_SIZE):
                if hidden[i] == 'M':
                    visible[i] = MINE
                    
            # Determine Winner
            winner_text = ""
            if game['p1_score'] > game['p2_score']:
                winner_text = f"🏆 <b>{game['player_1_info']} wins the match!</b> 🎉"
            elif game['p2_score'] > game['p1_score']:
                winner_text = f"🏆 <b>{game['player_2_info']} wins the match!</b> 🎉"
            else:
                winner_text = "🤝 <b>It's a Tie!</b>"

            text = (
                f"💥 <b>BOOM! {current_icon} HIT A MINE!</b> 💥\n\n"
                f"🔴 {game['player_1_info']} Match Score: <b>{game['p1_score']}</b>\n"
                f"🔵 {game['player_2_info']} Match Score: <b>{game['p2_score']}</b>\n\n"
                f"{winner_text}\n\n"
                f"Type /ms to play again."
            )
            
            for _ in range(3):
                try:
                    await context.bot.edit_message_text(
                        chat_id=chat_id, message_id=game['message_id'],
                        text=text, reply_markup=get_board_markup(visible), parse_mode="HTML"
                    )
                    break
                except Exception:
                    await asyncio.sleep(0.5)
                    
            del active_games[chat_id]
            return
            
        # ==========================================
        # SAFE TILE CLICKED
        # ==========================================
        else:
            game['safe_revealed'] += points_earned
            game['last_action'] = f"✅ {current_icon} revealed {points_earned} safe tiles! (+{points_earned} pts)"
            
            # Apply points
            if game['turn'] == 1:
                game['p1_score'] += points_earned
                apply_global_points(game['player_1'].id, game['player_1_info'], points_earned)
            else:
                game['p2_score'] += points_earned
                apply_global_points(game['player_2'].id, game['player_2_info'], points_earned)

        # ==========================================
        # 🏆 GAME OVER LOGIC: PERFECT CLEAR!
        # ==========================================
        if game['safe_revealed'] >= TOTAL_SAFE_TILES:
            
            # Reveal the remaining mines safely to show the completed board
            for i in range(BOARD_SIZE * BOARD_SIZE):
                if hidden[i] == 'M':
                    visible[i] = MINE
                    
            winner_text = ""
            if game['p1_score'] > game['p2_score']:
                winner_text = f"🏆 <b>{game['player_1_info']} wins the match!</b> 🎉 (+10 Bonus)"
                apply_global_points(game['player_1'].id, game['player_1_info'], 10)
            elif game['p2_score'] > game['p1_score']:
                winner_text = f"🏆 <b>{game['player_2_info']} wins the match!</b> 🎉 (+10 Bonus)"
                apply_global_points(game['player_2'].id, game['player_2_info'], 10)
            else:
                winner_text = "🤝 <b>It's a Tie!</b>"

            text = (
                f"✨ <b>PERFECT CLEAR! ALL MINES DODGED!</b> ✨\n\n"
                f"🔴 {game['player_1_info']} Match Score: <b>{game['p1_score']}</b>\n"
                f"🔵 {game['player_2_info']} Match Score: <b>{game['p2_score']}</b>\n\n"
                f"{winner_text}\n\n"
                f"Type /ms to play again."
            )
            
            for _ in range(3):
                try:
                    await context.bot.edit_message_text(
                        chat_id=chat_id, message_id=game['message_id'],
                        text=text, reply_markup=get_board_markup(visible), parse_mode="HTML"
                    )
                    break
                except Exception:
                    await asyncio.sleep(0.5)
                    
            del active_games[chat_id]
            return

        # Switch turns
        game['turn'] = 2 if game['turn'] == 1 else 1
        next_icon = P1_ICON if game['turn'] == 1 else P2_ICON

        game['base_text'] = (
            f"🎮 <b>Minesweeper Raid</b>\n\n"
            f"🔴 Player 1: {game['player_1_info']} (Score: {game['p1_score']})\n"
            f"🔵 Player 2: {game['player_2_info']} (Score: {game['p2_score']})\n\n"
            f"{game['last_action']}\n\n"
            f"It is {next_icon}'s turn!"
        )
        game['time_left'] = 180
        
        new_job = context.job_queue.run_repeating(
            live_countdown, interval=3, first=3, data={'chat_id': chat_id}
        )
        game['timer_job'] = new_job

        text = f"{game['base_text']}\n\n(⏳ 180 seconds remaining)"
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(visible), 
                parse_mode="HTML"
            )
        except Exception:
            pass

    except Exception as e:
        print(f"Error processing move: {e}")
        
    finally:
        if chat_id in active_games:
            active_games[chat_id]['is_processing'] = False

async def check_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the Top 20 players for Minesweeper."""
    user = update.effective_user
    user_id_str = str(user.id)
    
    user_data = user_points.get(user_id_str, {"points": 0})
    personal_points = user_data["points"]

    sorted_players = sorted(user_points.items(), key=lambda x: x[1]['points'], reverse=True)
    top_20 = sorted_players[:20]

    if not top_20:
        await update.message.reply_text("📋 <b>Leaderboard is empty!</b> Play some games first.", parse_mode="HTML")
        return

    text = "🏆 <b>TOP 20 MINESWEEPER PLAYERS</b> 🏆\n━━━━━━━━━━━━━━━━━━━━\n"
    
    for rank, (uid, data) in enumerate(top_20, 1):
        if rank == 1: medal = "🥇"
        elif rank == 2: medal = "🥈"
        elif rank == 3: medal = "🥉"
        else: medal = "🏅"
        text += f"{medal} <b>{data['name']}</b>: {data['points']} pts\n"
        
    text += "━━━━━━━━━━━━━━━━━━━━\n"
    text += f"👤 <b>Your Total Points:</b> {personal_points}"

    await update.message.reply_text(text, parse_mode="HTML")

if __name__ == '__main__':
    app = Application.builder().token("8730956259:AAFuW-Iqrnmz58ks1IEya-4Ud2Y3im84LTk").build()

    app.add_handler(CommandHandler("ms", start_game))
    app.add_handler(CommandHandler("msclose", close_game)) 
    app.add_handler(CommandHandler("mspoints", check_points))
    app.add_handler(CommandHandler("msrules", show_rules))
    app.add_handler(CallbackQueryHandler(handle_move, pattern="^ms_"))

    print("Multiplayer Minesweeper Bot is running lag-free...")
    app.run_polling()
