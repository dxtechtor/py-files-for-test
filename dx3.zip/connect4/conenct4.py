import json
import os
import html
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# --- Persistent Data Storage Setup ---
POINTS_FILE = "c4points.json"

def load_points():
    """Loads points and upgrades formats automatically."""
    if os.path.exists(POINTS_FILE):
        with open(POINTS_FILE, "r") as file:
            try:
                data = json.load(file)
                for k, v in data.items():
                    if isinstance(v, int):
                        data[k] = {"points": v, "name": f"User_{k}"}
                return data
            except json.JSONDecodeError:
                return {}
    return {}

def save_points(points_data):
    """Saves the current points dictionary to the JSON file."""
    with open(POINTS_FILE, "w") as file:
        json.dump(points_data, file, indent=4)

# --- In-Memory Variables ---
active_games = {}
user_points = load_points()

# Game pieces
EMPTY = '⚪'
P1_PIECE = '🔴'
P2_PIECE = '🟡'

def get_player_info(user):
    """Returns the player's Full Name, safely escaped."""
    return html.escape(user.full_name)

def get_board_markup(board):
    """Generates the 7x6 inline keyboard for Connect Four."""
    keyboard = []
    # 6 Rows
    for r in range(6):
        row = []
        # 7 Columns
        for c in range(7):
            idx = r * 7 + c
            row.append(InlineKeyboardButton(board[idx], callback_data=f"c4_{c}"))
        keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

def check_win(board, piece):
    """Checks if there are 4 connected pieces horizontally, vertically, or diagonally."""
    # Check horizontal
    for c in range(4):
        for r in range(6):
            if board[r*7 + c] == piece and board[r*7 + c+1] == piece and board[r*7 + c+2] == piece and board[r*7 + c+3] == piece:
                return True
    # Check vertical
    for c in range(7):
        for r in range(3):
            if board[r*7 + c] == piece and board[(r+1)*7 + c] == piece and board[(r+2)*7 + c] == piece and board[(r+3)*7 + c] == piece:
                return True
    # Check positive diagonal
    for c in range(4):
        for r in range(3):
            if board[r*7 + c] == piece and board[(r+1)*7 + c+1] == piece and board[(r+2)*7 + c+2] == piece and board[(r+3)*7 + c+3] == piece:
                return True
    # Check negative diagonal
    for c in range(4):
        for r in range(3, 6):
            if board[r*7 + c] == piece and board[(r-1)*7 + c+1] == piece and board[(r-2)*7 + c+2] == piece and board[(r-3)*7 + c+3] == piece:
                return True
    return False

def drop_piece(board, col, piece):
    """Simulates gravity by placing the piece in the lowest empty row of the chosen column."""
    for r in range(5, -1, -1):
        if board[r*7 + col] == EMPTY:
            board[r*7 + col] = piece
            return True
    return False 

def safe_remove_job(job):
    """Safely removes a scheduled job, ignoring errors if it was already removed."""
    if job:
        try:
            job.schedule_removal()
        except Exception:
            pass

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /c4rules command to explain the game."""
    rules_text = (
        "🎮 <b>How to Play Connect 4</b> 🎮\n\n"
        "<b>The Goal:</b> Be the first player to get 4 of your pieces in a straight line (up, down, across, or diagonally).\n\n"
        "<b>How to move:</b>\n"
        "1️⃣ Type /c4 to start a game.\n"
        "2️⃣ Player 1 is 🔴. Player 2 (🟡) joins by tapping the board!\n"
        "3️⃣ Click <b>ANY</b> button in a column. Your piece will automatically fall to the lowest empty spot in that column!\n"
        "4️⃣ You have 60 seconds to make your move.\n\n"
        "<b>Commands:</b>\n"
        "• /c4 - Start a new game\n"
        "• /c4close - Force stop a stuck game\n"
        "• /c4points - Check the Top 20 leaderboard\n"
        "• /c4rules - Show this message"
    )
    await update.message.reply_text(rules_text, parse_mode="HTML")

async def live_countdown(context: ContextTypes.DEFAULT_TYPE):
    """Updates the message every 3 seconds to show a live countdown."""
    job = context.job
    chat_id = job.data['chat_id']

    if chat_id not in active_games:
        safe_remove_job(job)
        return

    game = active_games[chat_id]
    
    if game.get('is_processing'):
        return

    game['time_left'] -= 3

    if game['time_left'] <= 0:
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text="⏳ <b>Game Closed!</b>\n\nAutomatically closed due to 60 seconds of inactivity.\n\nType /c4 to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
        
        del active_games[chat_id]
        safe_remove_job(job)
    else:
        try:
            text = f"{game['base_text']}\n\n(⏳ {game['time_left']} seconds remaining)"
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text,
                reply_markup=get_board_markup(game['board']),
                parse_mode="HTML"
            )
        except Exception:
            pass 

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /c4 command to start a game."""
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        await update.message.reply_text("❌ A Connect Four game is already running in this group! Finish it or type /c4close to force close it.")
        return

    player_info = get_player_info(user)
    
    base_text = (
        f"🎮 <b>Connect Four started!</b>\n\n"
        f"🔴 Player 1: {player_info}\n"
        f"🟡 Player 2: Waiting for opponent...\n\n"
        f"It is 🔴's turn!\n\n"
        f"📖 <i>Type /c4rules for rules</i>"
    )

    active_games[chat_id] = {
        'board': [EMPTY] * 42, 
        'player_1': user,
        'player_1_info': player_info,
        'player_2': None,
        'player_2_info': "Waiting for opponent...",
        'turn': P1_PIECE,
        'message_id': None,
        'timer_job': None,
        'time_left': 60,
        'base_text': base_text,
        'is_processing': False
    }

    markup = get_board_markup(active_games[chat_id]['board'])
    message = await update.message.reply_text(
        f"{base_text}\n\n(⏳ 60 seconds remaining)",
        reply_markup=markup,
        parse_mode="HTML"
    )
    
    active_games[chat_id]['message_id'] = message.message_id

    job = context.job_queue.run_repeating(
        live_countdown, 
        interval=3, 
        first=3,
        data={'chat_id': chat_id}
    )
    active_games[chat_id]['timer_job'] = job

async def close_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /c4close command."""
    chat_id = update.effective_chat.id
    user = update.effective_user

    if chat_id in active_games:
        game = active_games[chat_id]
        safe_remove_job(game.get('timer_job'))
        closer_name = get_player_info(user)
            
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=f"🛑 <b>Game Forcefully Closed!</b>\n\nGame has closed by {closer_name}.\n\nType /c4 to start a new game.",
                parse_mode="HTML"
            )
        except Exception:
            pass 
            
        del active_games[chat_id]
        await update.message.reply_text(f"✅ Game has closed by <b>{closer_name}</b>.", parse_mode="HTML")
    else:
        await update.message.reply_text("ℹ️ There is no active Connect Four game running right now.", parse_mode="HTML")


async def handle_move(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles button clicks on the Connect Four board."""
    query = update.callback_query
    chat_id = update.effective_chat.id
    user = update.effective_user
    data = query.data

    if not data.startswith("c4_"):
        return

    if chat_id not in active_games:
        await query.answer("This game has already ended or timed out!", show_alert=True)
        return

    game = active_games[chat_id]

    if game.get('is_processing'):
        await query.answer("⏳ Wait a moment...", show_alert=False)
        return

    if query.message.message_id != game['message_id']:
        await query.answer("This is an old game board!", show_alert=True)
        return

    # Extract the column number (0-6) from the button click
    col = int(data.split('_')[1])
    board = game['board']

    # Turn logic and Player 2 joining
    if game['turn'] == P1_PIECE:
        if user.id != game['player_1'].id:
            await query.answer("It's not your turn, or you are not Player 🔴!", show_alert=True)
            return
    else:
        if game['player_2'] is None:
            if user.id == game['player_1'].id:
                await query.answer("You can't play against yourself! Let someone else join.", show_alert=True)
                return
            game['player_2'] = user
            game['player_2_info'] = get_player_info(user)
        elif user.id != game['player_2'].id:
            await query.answer("It's not your turn, or you are not Player 🟡!", show_alert=True)
            return

    # Check if the column is completely full BEFORE locking
    # The top row indices are 0 to 6, so board[col] represents the very top of that column!
    if board[col] != EMPTY:
        await query.answer("That column is completely full! Pick another.", show_alert=False)
        return

    # Acknowledge the tap IMMEDIATELY to prevent Telegram timeouts/lag spinners!
    await query.answer()
    
    # Now lock the board to process the drop safely
    game['is_processing'] = True

    try:
        drop_piece(board, col, game['turn'])
        safe_remove_job(game.get('timer_job'))

        # Check Win
        if check_win(board, game['turn']):
            winning_user = game['player_1'] if game['turn'] == P1_PIECE else game['player_2']
            winning_info = get_player_info(winning_user)
            
            user_id_str = str(winning_user.id)
            if user_id_str not in user_points:
                user_points[user_id_str] = {"points": 0, "name": winning_info}
                
            user_points[user_id_str]["points"] += 15 
            user_points[user_id_str]["name"] = winning_info 
            save_points(user_points) 
            
            text = f"🏆 <b>Game Over!</b>\n\nWinner: {winning_info}\nEarned <b>15 points</b>! 🎉\n\nType /c4 to play again."
            
            # Using context.bot directly prevents "Query too old" errors from freezing updates
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(board), 
                parse_mode="HTML"
            )
            del active_games[chat_id]
            
        elif EMPTY not in board:
            text = "🤝 <b>Game Over!</b>\n\nIt's a draw! The board is full.\n\nType /c4 to play again."
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(board), 
                parse_mode="HTML"
            )
            del active_games[chat_id]
            
        else:
            # Switch Turns
            game['turn'] = P2_PIECE if game['turn'] == P1_PIECE else P1_PIECE
            
            game['base_text'] = (
                f"🎮 <b>Connect Four</b>\n\n"
                f"🔴 Player 1: {game['player_1_info']}\n"
                f"🟡 Player 2: {game['player_2_info']}\n\n"
                f"It is <b>{game['turn']}</b>'s turn!\n\n"
                f"📖 <i>Type /c4rules for rules</i>"
            )
            
            game['time_left'] = 60
            
            text = f"{game['base_text']}\n\n(⏳ 60 seconds remaining)"
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=game['message_id'],
                text=text, 
                reply_markup=get_board_markup(board), 
                parse_mode="HTML"
            )
            
            new_job = context.job_queue.run_repeating(
                live_countdown, 
                interval=3, 
                first=3,
                data={'chat_id': chat_id}
            )
            game['timer_job'] = new_job

    except Exception as e:
        # Fails silently so the background timer can auto-correct the board 3 seconds later!
        pass 
        
    finally:
        if chat_id in active_games:
            active_games[chat_id]['is_processing'] = False

async def check_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the Top 20 players for Connect Four."""
    user = update.effective_user
    user_id_str = str(user.id)
    
    user_data = user_points.get(user_id_str, {"points": 0})
    personal_points = user_data["points"]

    sorted_players = sorted(user_points.items(), key=lambda x: x[1]['points'], reverse=True)
    top_20 = sorted_players[:20]

    if not top_20:
        await update.message.reply_text("📋 <b>Leaderboard is empty!</b> Play some games first.", parse_mode="HTML")
        return

    text = "🏆 <b>TOP 20 CONNECT 4 PLAYERS</b> 🏆\n━━━━━━━━━━━━━━━━━━━━\n"
    
    for rank, (uid, data) in enumerate(top_20, 1):
        if rank == 1:
            medal = "🥇"
        elif rank == 2:
            medal = "🥈"
        elif rank == 3:
            medal = "🥉"
        else:
            medal = "🏅"
            
        text += f"{medal} <b>{data['name']}</b>: {data['points']} pts\n"
        
    text += "━━━━━━━━━━━━━━━━━━━━\n"
    text += f"👤 <b>Your Total Points:</b> {personal_points}"

    await update.message.reply_text(text, parse_mode="HTML")

if __name__ == '__main__':
    app = Application.builder().token("8730956259:AAFuW-Iqrnmz58ks1IEya-4Ud2Y3im84LTk").build()

    app.add_handler(CommandHandler("c4", start_game))
    app.add_handler(CommandHandler("c4close", close_game)) 
    app.add_handler(CommandHandler("c4points", check_points))
    app.add_handler(CommandHandler("c4rules", show_rules))
    app.add_handler(CallbackQueryHandler(handle_move, pattern="^c4_"))

    print("Connect Four Bot is running lag-free...")
    app.run_polling()
