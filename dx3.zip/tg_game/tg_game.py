import json
import os
import asyncio
import threading
from flask import Flask, jsonify, request, send_from_directory
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler

# --- CONFIGURATION ---
BOT_TOKEN = '8974792246:AAE48Hy17r-8pCWa2K3VoWMXnWxL0GAwJZg'
GROUP_ID = '-1003995771127'
PORT = 8080
SCORE_FILE = 'scores.json'
URL = "https://cahoots-skies-sublime.ngrok-free.dev/"
GOAL_LIMIT = 15000
AUTHORIZED_ID = 8626582205

# Global Variables
ADMIN_NAMES = ["@Legit0flash"]
REVEALED = False

app = Flask(__name__, static_folder='static')

def load_scores():
    if os.path.exists(SCORE_FILE):
        with open(SCORE_FILE, 'r') as f:
            try: return json.load(f)
            except: return []
    return []

def save_scores(scores):
    with open(SCORE_FILE, 'w') as f: json.dump(scores, f)

# --- WEB SERVER ROUTES ---
@app.route('/')
def game(): return send_from_directory('static', 'index.html')

@app.route('/get_game_state', methods=['GET'])
def get_game_state():
    global REVEALED
    scores = load_scores()
    total = sum(s['score'] for s in scores)
    if total >= GOAL_LIMIT: REVEALED = True
    return jsonify({"total": total, "revealed": REVEALED, "admins": ADMIN_NAMES, "goal_limit": GOAL_LIMIT})

@app.route('/get_global_score', methods=['GET'])
def get_global_score():
    scores = load_scores()
    total = sum(s['score'] for s in scores)
    return jsonify({"total": total})

@app.route('/get_leaderboard', methods=['GET'])
def get_leaderboard():
    scores = load_scores()
    player_totals = {}
    for entry in scores:
        player_totals[entry['name']] = player_totals.get(entry['name'], 0) + entry['score']
    sorted_players = sorted(player_totals.items(), key=lambda x: x[1], reverse=True)[:10]
    return jsonify([{"name": k, "score": v} for k, v in sorted_players])

@app.route('/submit_score', methods=['POST'])
def submit_score():
    global REVEALED
    data = request.json
    points = data.get('score', 0)
    name = data.get('name', 'Player')
    
    scores = load_scores()
    scores.append({"name": name, "score": points})
    save_scores(scores)
    
    total = sum(s['score'] for s in scores)
    is_now_revealed = False
    
    if total >= GOAL_LIMIT and not REVEALED:
        REVEALED = True
        is_now_revealed = True
        admin_str = ", ".join(ADMIN_NAMES)
        asyncio.run_coroutine_threadsafe(
            application.bot.send_message(chat_id=GROUP_ID, text=f"🎉 VICTORY! Admins: {admin_str}"),
            application.loop
        )
    return jsonify({"status": "ok", "total": total, "revealed": is_now_revealed, "goal_limit": GOAL_LIMIT})

# --- TELEGRAM BOT LOGIC ---
async def task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    bot_url = f"https://t.me/{context.bot.username}"
    keyboard = [[InlineKeyboardButton("Play Game", url=bot_url)]]
    await update.message.reply_text("Click to play the game!", reply_markup=InlineKeyboardMarkup(keyboard))

async def set_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global ADMIN_NAMES
    if update.effective_user.id != AUTHORIZED_ID:
        await update.message.reply_text("⛔ You are not authorized.")
        return

    if context.args:
        ADMIN_NAMES = [name if name.startswith("@") else "@" + name for name in context.args]
        await update.message.reply_text(f"✅ Admins updated to: {', '.join(ADMIN_NAMES)}")
    else:
        await update.message.reply_text("Usage: /set_admin @admin1 @admin2")

async def set_goal_limit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global GOAL_LIMIT
    if update.effective_user.id != AUTHORIZED_ID:
        await update.message.reply_text("⛔ You are not authorized.")
        return

    if context.args:
        try:
            new_limit = int(context.args[0])
            GOAL_LIMIT = new_limit
            await update.message.reply_text(f"✅ Goal limit successfully updated to: {GOAL_LIMIT}")
        except ValueError:
            await update.message.reply_text("❌ Please enter a valid number.")
    else:
        await update.message.reply_text("Usage: /set_limit <amount>")

if __name__ == '__main__':
    application = ApplicationBuilder().token(BOT_TOKEN).build()
    application.add_handler(CommandHandler('task', task))
    application.add_handler(CommandHandler('set_admin', set_admin))
    application.add_handler(CommandHandler('set_limit', set_goal_limit))
    
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT), daemon=True).start()
    application.run_polling()
