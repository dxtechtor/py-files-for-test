from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pathlib import Path
import asyncio
import json
import math
import random
import time
import uvicorn
import pymunk

app = FastAPI()
BASE_DIR = Path(__file__).resolve().parent

# --- Game State ---
state = {
    "status": "lobby", 
    "team1": [], 
    "team2": [],
    "ready_players": set(),
    "placement_ready": set(),
    "score": {"team1": 0, "team2": 0},
    "player_goals": {"team1": {}, "team2": {}}, 
    "max_goals": 3,
    "turn": {"team": 1, "t1_index": -1, "t2_index": -1, "active_human": "", "active_player_id": None, "turn_id": 0, "time_left": 30},
    "is_moving": False
}

connected_clients = {}
client_names = {} 
space = pymunk.Space()
space.damping = 0.5 

physics_objects = {"ball": None, "players": []}

# --- TRUE CARROM BOARD PHYSICS ---
def ball_player_pre_solve(arbiter, space, data):
    ball_shape = arbiter.shapes[0] if arbiter.shapes[0].collision_type == 1 else arbiter.shapes[1]
    player_shape = arbiter.shapes[1] if arbiter.shapes[0].collision_type == 1 else arbiter.shapes[0]
    
    p_team = 1 if player_shape.collision_type == 2 else 2
    active_team = state["turn"]["team"]
    
    if p_team == active_team:
        # ALLOW natural physics! This calculates the exact reflection angles (Carrom style).
        return True 
    else:
        # Ball hits OPPOSING team: Stop dead immediately
        if ball_shape.body.velocity.length > 1:
            ball_shape.body.velocity = (0, 0)
            ball_shape.body.angular_velocity = 0
            player_shape.body.velocity = (0, 0)
            player_shape.body.angular_velocity = 0
        return False 

def ball_player_post_solve(arbiter, space, data):
    # This runs the exact millisecond AFTER the natural carrom bounce happens
    ball_shape = arbiter.shapes[0] if arbiter.shapes[0].collision_type == 1 else arbiter.shapes[1]
    player_shape = arbiter.shapes[1] if arbiter.shapes[0].collision_type == 1 else arbiter.shapes[0]
    
    p_team = 1 if player_shape.collision_type == 2 else 2
    active_team = state["turn"]["team"]
    
    if p_team == active_team:
        # 1. Freeze the striker dead in its tracks after it transfers its momentum
        player_shape.body.velocity = (0, 0)
        player_shape.body.angular_velocity = 0
        
        # 2. Add extra punch to the ball so it flies faster off the carrom hit
        if arbiter.is_first_contact:
            ball_shape.body.velocity = ball_shape.body.velocity * 1.5

# Register BOTH pre_solve (to allow angles) and post_solve (to freeze the striker)
space.on_collision(1, 2, pre_solve=ball_player_pre_solve, post_solve=ball_player_post_solve)
space.on_collision(1, 3, pre_solve=ball_player_pre_solve, post_solve=ball_player_post_solve)

@app.get("/")
@app.get("/index.html")
async def get():
    headers = {"Cache-Control": "no-cache, no-store, must-revalidate"}
    return FileResponse(BASE_DIR / "index.html", headers=headers)

def setup_field():
    global space
    for shape in list(space.shapes): space.remove(shape)
    for body in list(space.bodies): space.remove(body)
    
    static_body = space.static_body
    walls = [
        # Main Boundary Walls (Thickness reduced from 200 to 10 to unblock the net!)
        pymunk.Segment(static_body, (0, -10), (1000, -10), 10),      # Top
        pymunk.Segment(static_body, (0, 610), (1000, 610), 10),      # Bottom
        pymunk.Segment(static_body, (-10, 0), (-10, 200), 10),       # Left Top
        pymunk.Segment(static_body, (-10, 400), (-10, 600), 10),     # Left Bottom
        pymunk.Segment(static_body, (1010, 0), (1010, 200), 10),     # Right Top
        pymunk.Segment(static_body, (1010, 400), (1010, 600), 10),   # Right Bottom
        
        # Left Goal Net
        pymunk.Segment(static_body, (0, 200), (-40, 200), 5),    
        pymunk.Segment(static_body, (-40, 200), (-40, 400), 5),  
        pymunk.Segment(static_body, (-40, 400), (0, 400), 5),    
        
        # Right Goal Net
        pymunk.Segment(static_body, (1000, 200), (1040, 200), 5),   
        pymunk.Segment(static_body, (1040, 200), (1040, 400), 5),   
        pymunk.Segment(static_body, (1040, 400), (1000, 400), 5)    
    ]


    for w in walls:
        w.elasticity = 0.3 
        w.collision_type = 4
        space.add(w)
    
    physics_objects["players"] = []
    
    ball_body = pymunk.Body(1, pymunk.moment_for_circle(1, 0, 10))
    ball_body.position = (500, 300)
    ball_shape = pymunk.Circle(ball_body, 10)
    ball_shape.elasticity = 0.8 
    ball_shape.collision_type = 1
    space.add(ball_body, ball_shape)
    physics_objects["ball"] = ball_body

    def spawn_team(team_list, team_num, start_x, direction):
        for i in range(11):
            name = team_list[i] if i < len(team_list) else f"Bot_{i+1}"
            is_bot = i >= len(team_list)
            body = pymunk.Body(10, pymunk.moment_for_circle(10, 0, 15))
            
            # Smart Default Placement outside of restricted zones
            y_pos = 100 + (i * 40) % 400
            x_pos = start_x + (i % 3) * 100 * direction
            if team_num == 1 and x_pos < 165 and 135 < y_pos < 465: x_pos = 165
            if team_num == 2 and x_pos > 835 and 135 < y_pos < 465: x_pos = 835
            
            body.position = (x_pos, y_pos)
            p_id = f"t{team_num}_{i}"
            body.p_id = p_id 
            
            shape = pymunk.Circle(body, 15)
            shape.elasticity = 0.6 
            shape.collision_type = 2 if team_num == 1 else 3
            
            PLAYER_CATEGORY = 0b10
            shape.filter = pymunk.ShapeFilter(categories=PLAYER_CATEGORY, mask=pymunk.ShapeFilter.ALL_MASKS() ^ PLAYER_CATEGORY)
            
            space.add(body, shape)
            physics_objects["players"].append({
                "id": p_id, "body": body, "name": name, "team": team_num, "is_bot": is_bot
            })

    spawn_team(state["team1"], 1, 300, -1)
    spawn_team(state["team2"], 2, 700, 1)

def assign_possession():
    active_team = state["turn"]["team"]
    bx, by = physics_objects["ball"].position
    closest_player = None
    min_dist = float('inf')
    
    for p in physics_objects["players"]:
        if p["team"] == active_team:
            dist = math.hypot(p["body"].position.x - bx, p["body"].position.y - by)
            if dist < min_dist:
                min_dist = dist
                closest_player = p
                
    if closest_player:
        state["turn"]["active_player_id"] = closest_player["id"]
        active_human_name = state["turn"]["active_human"]
        
        if closest_player["name"] != active_human_name and active_human_name != "Bot":
            human_player = next((p for p in physics_objects["players"] if p["name"] == active_human_name and p["team"] == active_team), None)
            
            if human_player:
                temp_name, temp_bot = closest_player["name"], closest_player["is_bot"]
                closest_player["name"], closest_player["is_bot"] = human_player["name"], human_player["is_bot"]
                human_player["name"], human_player["is_bot"] = temp_name, temp_bot

    T1_CAT = 0b0010
    T2_CAT = 0b0100
    ACTIVE_CAT = 0b1000
    ALL_PLAYERS_MASK = T1_CAT | T2_CAT | ACTIVE_CAT
    
    for p in physics_objects["players"]:
        shape = list(p["body"].shapes)[0]
        if p["id"] == state["turn"]["active_player_id"]:
            cat = ACTIVE_CAT
        elif p["team"] == 1:
            cat = T1_CAT
        else:
            cat = T2_CAT
        shape.filter = pymunk.ShapeFilter(categories=cat, mask=pymunk.ShapeFilter.ALL_MASKS() ^ ALL_PLAYERS_MASK)
        
    if physics_objects["ball"]:
        ball_shape = list(physics_objects["ball"].shapes)[0]
        if active_team == 1:
            ball_shape.filter = pymunk.ShapeFilter(mask=pymunk.ShapeFilter.ALL_MASKS() ^ T1_CAT)
        else:
            ball_shape.filter = pymunk.ShapeFilter(mask=pymunk.ShapeFilter.ALL_MASKS() ^ T2_CAT)

async def turn_timer_task(turn_id, duration):
    for i in range(duration, -1, -1):
        await asyncio.sleep(1)
        if state["turn"].get("turn_id") != turn_id or state["is_moving"] or state["status"] != "playing":
            return
        
        state["turn"]["time_left"] = i
        await broadcast_state()
    
    t_num = state["turn"]["team"]
    team_list = state["team1"] if t_num == 1 else state["team2"]
    
    if team_list:
        idx_key = f"t{t_num}_index"
        state["turn"][idx_key] = (state["turn"].get(idx_key, -1) + 1) % len(team_list)
        state["turn"]["active_human"] = team_list[state["turn"][idx_key]]
    
    assign_possession()
    start_new_turn_timer()
    await broadcast_state()

def start_new_turn_timer():
    state["turn"]["turn_id"] = state["turn"].get("turn_id", 0) + 1
    duration = 3 if state["turn"]["active_human"] == "Bot" else 30
    state["turn"]["time_left"] = duration
    asyncio.create_task(turn_timer_task(state["turn"]["turn_id"], duration))

def next_turn():
    state["turn"]["team"] = 2 if state["turn"]["team"] == 1 else 1
    t_num = state["turn"]["team"]
    team_list = state["team1"] if t_num == 1 else state["team2"]
    
    if not team_list:
        t_num = 2 if t_num == 1 else 1
        state["turn"]["team"] = t_num
        team_list = state["team1"] if t_num == 1 else state["team2"]

    if team_list:
        idx_key = f"t{t_num}_index"
        state["turn"][idx_key] = (state["turn"].get(idx_key, -1) + 1) % len(team_list)
        state["turn"]["active_human"] = team_list[state["turn"][idx_key]]
    else:
        state["turn"]["active_human"] = "Bot"
        
    assign_possession()
    start_new_turn_timer()

def get_serializable_state():
    has_players = bool(state["team1"] and state["team2"])
    t1_all_ready = all(n in state["ready_players"] for n in state["team1"]) if state["team1"] else False
    t2_all_ready = all(n in state["ready_players"] for n in state["team2"]) if state["team2"] else False
    canStart = has_players and t1_all_ready and t2_all_ready
    
    players_data = []
    for p in physics_objects["players"]:
        players_data.append({
            "id": p["id"], "name": p["name"], "team": p["team"], "is_bot": p["is_bot"],
            "x": int(p["body"].position.x), "y": int(p["body"].position.y), "radius": 15
        })
        
    ball_pos = {"x": int(physics_objects["ball"].position.x), "y": int(physics_objects["ball"].position.y), "radius": 10} if physics_objects["ball"] else {"x": 500, "y": 300, "radius": 10}

    return {
        "status": state["status"],
        "team1_roster": state["team1"],
        "team2_roster": state["team2"],
        "ready_players": list(state["ready_players"]),
        "placement_ready": list(state["placement_ready"]),
        "canStart": canStart,
        "score": state["score"],
        "player_goals": state["player_goals"], 
        "max_goals": state["max_goals"],
        "turn": state["turn"],
        "is_moving": state["is_moving"], 
        "ball": ball_pos,
        "players": players_data
    }

async def broadcast_state():
    safe_state = get_serializable_state()
    for client in connected_clients.values():
        try: await client.send_text(json.dumps(safe_state))
        except: pass

async def physics_loop():
    if state["is_moving"]: return 
    state["is_moving"] = True
    moving = True
    await broadcast_state() 
    
    MAX_SPEED = 2000 
    frame_count = 0 
    
    try:
        while moving and frame_count < 150:
            space.step(1/30.0) 
            moving = False
            frame_count += 1
            
            if physics_objects["ball"].velocity.length > MAX_SPEED:
                physics_objects["ball"].velocity = physics_objects["ball"].velocity.normalized() * MAX_SPEED
            for p in physics_objects["players"]:
                if p["body"].velocity.length > MAX_SPEED:
                    p["body"].velocity = p["body"].velocity.normalized() * MAX_SPEED

            physics_objects["ball"].velocity = physics_objects["ball"].velocity * 0.985 
            for p in physics_objects["players"]:
                p["body"].velocity = p["body"].velocity * 0.98
                
            if abs(physics_objects["ball"].velocity.x) > 3 or abs(physics_objects["ball"].velocity.y) > 3:
                moving = True
            for p in physics_objects["players"]:
                if abs(p["body"].velocity.x) > 3 or abs(p["body"].velocity.y) > 3:
                    moving = True
                    break
                    
            bx, by = physics_objects["ball"].position
            
            if bx < 5 and 200 < by < 400:
                state["score"]["team2"] += 1
                if state["turn"]["team"] == 2:
                    scorer = state["turn"]["active_human"]
                    state["player_goals"]["team2"][scorer] = state["player_goals"]["team2"].get(scorer, 0) + 1
                moving = False
                state["status"] = "placement"
                state["placement_ready"].clear()
                setup_field()
                
            elif bx > 995 and 200 < by < 400:
                state["score"]["team1"] += 1
                if state["turn"]["team"] == 1:
                    scorer = state["turn"]["active_human"]
                    state["player_goals"]["team1"][scorer] = state["player_goals"]["team1"].get(scorer, 0) + 1
                moving = False
                state["status"] = "placement"
                state["placement_ready"].clear()
                setup_field()

            await broadcast_state()
            await asyncio.sleep(0.03) 
            
    finally:
        state["is_moving"] = False
        physics_objects["ball"].velocity = (0,0)
        for p in physics_objects["players"]: p["body"].velocity = (0,0)
        
        if state["score"]["team1"] >= state["max_goals"] or state["score"]["team2"] >= state["max_goals"]:
            state["status"] = "game_over"
        elif state["status"] == "playing":
            next_turn()
        await broadcast_state()

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await websocket.accept()
    connected_clients[client_id] = websocket
    
    try:
        await websocket.send_text(json.dumps(get_serializable_state()))
        
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            
            if msg["type"] == "reset_game":
                state["status"] = "lobby"
                state["score"] = {"team1": 0, "team2": 0}
                state["player_goals"] = {"team1": {}, "team2": {}} 
                state["ready_players"].clear()
                state["placement_ready"].clear()
                state["turn"] = {"team": 1, "t1_index": -1, "t2_index": -1, "active_human": "", "active_player_id": None, "turn_id": 0, "time_left": 30}
                setup_field()
                await broadcast_state()

            elif msg["type"] == "set_max_goals":
                state["max_goals"] = max(1, min(15, int(msg["value"])))
                await broadcast_state()
            
            elif msg["type"] == "rejoin":
                team_num = msg["team"]
                name = msg["name"]
                client_names[client_id] = name
                
                if name not in state["team1"] and name not in state["team2"]:
                    if team_num == 1: state["team1"].append(name)
                    elif team_num == 2: state["team2"].append(name)
                
                if state["status"] in ["playing", "placement"]:
                    existing = any(p["name"] == name for p in physics_objects["players"])
                    if not existing:
                        for p in physics_objects["players"]:
                            if p["team"] == team_num and p["is_bot"]:
                                p["name"] = name
                                p["is_bot"] = False
                                break
                    if state["turn"]["active_human"] == "Bot" and state["turn"]["team"] == team_num:
                        state["turn"]["active_human"] = name
                        assign_possession()
                await broadcast_state()
            
            elif msg["type"] == "ready":
                team_num = msg["team"]
                name = msg["name"]
                
                old_name = client_names.get(client_id)
                if old_name and old_name != name:
                    if old_name in state["team1"]: state["team1"].remove(old_name)
                    if old_name in state["team2"]: state["team2"].remove(old_name)
                    state["ready_players"].discard(old_name)
                    state["placement_ready"].discard(old_name)
                
                client_names[client_id] = name
                
                if name in state["team1"]: state["team1"].remove(name)
                if name in state["team2"]: state["team2"].remove(name)
                
                if team_num == 1: state["team1"].append(name)
                elif team_num == 2: state["team2"].append(name)
                
                if msg["ready"]: state["ready_players"].add(name)
                else: state["ready_players"].discard(name)
                
                await broadcast_state()
                
            elif msg["type"] == "start_placement":
                state["status"] = "placement"
                state["placement_ready"].clear()
                setup_field()
                await broadcast_state()
                
            elif msg["type"] == "place_player" and state["status"] == "placement":
                if msg.get("name") not in state["placement_ready"]:
                    for p in physics_objects["players"]:
                        if p["id"] == msg["p_id"] and p["team"] == msg["team"]:
                            if p["name"] == msg.get("name") or p["is_bot"]:
                                new_x = msg["x"]
                                new_y = msg["y"]
                                
                                # --- SERVER SIDE PLACEMENT CONSTRAINTS ---
                                if p["team"] == 1:
                                    new_x = max(15, min(485, new_x))
                                    if new_x < 165 and 135 < new_y < 465: new_x = 165
                                else:
                                    new_x = max(515, min(985, new_x))
                                    if new_x > 835 and 135 < new_y < 465: new_x = 835
                                        
                                dist_to_center = math.hypot(new_x - 500, new_y - 300)
                                if dist_to_center < 85:
                                    angle = math.atan2(new_y - 300, new_x - 500)
                                    new_x = 500 + math.cos(angle) * 85
                                    new_y = 300 + math.sin(angle) * 85
                                    
                                    if p["team"] == 1 and new_x > 485:
                                        new_x = 485
                                        new_y = 384 if new_y > 300 else 216
                                    elif p["team"] == 2 and new_x < 515:
                                        new_x = 515
                                        new_y = 384 if new_y > 300 else 216
                                        
                                new_y = max(15, min(585, new_y))
                                # -----------------------------------------
                                
                                p["body"].position = (new_x, new_y)
                                break
                await broadcast_state()
                
            elif msg["type"] == "placement_ready":
                state["placement_ready"].add(msg["name"])
                
                t1_all = all(n in state["placement_ready"] for n in state["team1"]) if state["team1"] else True
                t2_all = all(n in state["placement_ready"] for n in state["team2"]) if state["team2"] else True
                
                if t1_all and t2_all and (state["team1"] or state["team2"]):
                    state["status"] = "playing"
                    state["turn"]["team"] = random.choice([1, 2])
                    next_turn()
                await broadcast_state()
                
            elif msg["type"] == "shoot" and not state["is_moving"]:
                if msg["name"] == state["turn"]["active_human"]:
                    max_drag = 200
                    drag_len = math.hypot(msg["vx"], msg["vy"])
                    if drag_len > max_drag:
                        msg["vx"] = (msg["vx"] / drag_len) * max_drag
                        msg["vy"] = (msg["vy"] / drag_len) * max_drag
                    
                    for p in physics_objects["players"]:
                        if p["id"] == state["turn"]["active_player_id"]:
                            bx, by = physics_objects["ball"].position
                            dist = math.hypot(p["body"].position.x - bx, p["body"].position.y - by)
                            
                            if dist <= 35:
                                direct_power_multiplier = 7 
                                physics_objects["ball"].activate()
                                physics_objects["ball"].apply_impulse_at_local_point((msg["vx"] * direct_power_multiplier, msg["vy"] * direct_power_multiplier), (0, 0))
                            else:
                                power_multiplier = 45 
                                physics_objects["ball"].activate()
                                p["body"].activate()
                                p["body"].apply_impulse_at_local_point((msg["vx"] * power_multiplier, msg["vy"] * power_multiplier), (0, 0))
                            break
                    asyncio.create_task(physics_loop())

    except Exception as e:
        pass
    finally:
        disconnected_name = client_names.get(client_id)
        
        # 1. Remove connection
        if client_id in connected_clients:
            del connected_clients[client_id]
        if client_id in client_names:
            del client_names[client_id]
            
        # 2. Wipe the disconnected user from all game states
        if disconnected_name:
            changed = False
            if disconnected_name in state["team1"]: 
                state["team1"].remove(disconnected_name)
                changed = True
            if disconnected_name in state["team2"]: 
                state["team2"].remove(disconnected_name)
                changed = True
            if disconnected_name in state["ready_players"]:
                state["ready_players"].discard(disconnected_name)
                changed = True
            if disconnected_name in state["placement_ready"]:
                state["placement_ready"].discard(disconnected_name)
                changed = True
                
            # 3. If they leave mid-game, instantly turn them into a Bot
            if state["status"] in ["playing", "placement"]:
                for p in physics_objects["players"]:
                    if p["name"] == disconnected_name:
                        p["name"] = "Bot"
                        p["is_bot"] = True
                        changed = True
                if state["turn"]["active_human"] == disconnected_name:
                    state["turn"]["active_human"] = "Bot"
                    assign_possession()
                    changed = True
            
            # 4. Push the update to everyone else so the game can start!
            if changed:
                await broadcast_state()


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
