import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

# Replace with your actual Bot Token
BOT_TOKEN = "8681850131:AAH3af_GgLE4g4zeF5EFvkUE2By00Zq-zlQ"
bot = telebot.TeleBot(BOT_TOKEN)

# IMPORTANT: Replace the URL below with the one Ngrok gives you 
# when you run "ngrok http 8000" in your terminal.
NGROK_URL = "https://cahoots-skies-sublime.ngrok-free.dev"

@bot.message_handler(commands=['start', 'play'])
def play_football(message):
    markup = InlineKeyboardMarkup()
    
    # This creates the button that launches the game in the Telegram Mini App
    # We point it to /index.html as served by your server.py
    game_url = f"{NGROK_URL}/index.html"
    webapp = WebAppInfo(url=game_url)
    
    markup.add(InlineKeyboardButton("⚽ Play Football Arena", web_app=webapp))
    
    bot.send_message(
        message.chat.id, 
        "Welcome to the 22-Player Football Arena! 🏟️\n\n"
        "Click the button below to join the match.", 
        reply_markup=markup
    )

print("🚀 Football Bot is running...")
bot.infinity_polling()
